declare module 'num-words' {
  export default function numWords(n: number): string;
}
