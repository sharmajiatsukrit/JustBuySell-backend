export enum UserAgentType {
    ArchChatIos = "ArkChat",
}

export enum RedisChannels {
    NEWNOTIFICATION = "NEW-NOTIFICATION",
}

export enum BillingGatewayEnum {
    Stripe = 1,
    Paypal = 2,
    Paytm = 3,
    Apple = 4
}
