// import { body, param } from 'express-validator';

export default function validate(methodName: string) {
    switch (methodName) {
        default:
            return [];
    }
}
